<?php

return array(
	'id1'=>array(
		'id' => '1',
		'status' => 'workflow1/S1',
	),
	'id2'=>array(
		'id' => '2',
		'status' => 'workflow1/S2',
	),
	'id3'=>array(
		'id' => '3',
		'status' => 'workflowWithTask/S1',
	),
	'id4'=>array(
		'id' => '4',
		'status' => 'workflowPartial1/S1',
	),
	'id5'=>array(
		'id' => '5',
		'status' => 'MetadataWorkflow/S1',
	),
	'id6'=>array(
		'id' => '6',
		'status' => 'workflowEvent/S1',
	),
	'id7'=>array(
		'id' => '7',
		'status' => 'workflowEvent/S2',
	),
);
