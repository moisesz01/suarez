<?php
class SimpleWorkflowGenerator extends CCodeGenerator
{
    public $codeModel='application.gii.simpleWorkflow.SimpleWorkflowCode';
}
?>